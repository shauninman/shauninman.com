-----------------------------------------------------------
INSTALL

1. Move Day-O.app into /Applications/
2. Open Day-O.app
3. Select Date & Time... from the Day-O menu to open 
   the Clock tab of the Date & Time pane of the System 
   Preferences.app
4. Uncheck "Show date and time in menu bar"
5. Quit System Preferences.app

Still on El Capitan (or just like a tidy menu bar)? I love
Surtees Studios' Bartender.app: https://www.macbartender.com

-----------------------------------------------------------
NEW IN TWO

- supports dark mode and transparency
- fixed unresponsive calendar controls
- matches type and color of the default system menu bar items
- uses a monospaced-digits version of the system font when 
  seconds or fractions of seconds are displayed to prevent 
  constant, visually-distracting, menu bar shifting
- padded calendar widget for better alignment with other items 
  in the menu
- minimizes energy use where possible (note that the `S` and 
  `A` symbols require constant redrawing of the menu bar item 
  and therefore use more power)
- redraws the menu bar item when the menu is open (only really 
  noticeable when displaying seconds or fractions of seconds)
- no longer forces itself to the right of the menu bar (used 
  undocumented APIs which disappeared in El Capitan)
- redesigned Date & Time Format documentation hosted at
  http://shauninman.com/day-o/datetime.html
- icon
- rewritten from scratch in Swift 3.0 (yay?)

-----------------------------------------------------------
KNOWN ISSUES

- using arrow keys to navigate menu after scrubbing menu with 
  mouse doesn't work (until you open the Preferences window?)
- clicking on calendar days is disabled (provided no utility, 
  produced poor rendering in dark mode)

-----------------------------------------------------------
THANKS FOR PLAYING

Day-O is offered as-is. I won't be offering support or taking
feature requests. That said, I hope Day-O treats you well!

http://shauninman.com/archive/2016/10/20/day_o_2_mac_menu_bar_clock
