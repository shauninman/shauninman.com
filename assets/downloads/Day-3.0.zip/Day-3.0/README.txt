-----------------------------------------------------------
INSTALL

1. Move Day-O.app into /Applications/
2. Open Day-O.app
3. Select Date & Time... from the Day-O menu to open 
   the Clock tab of the Date & Time pane of the System 
   Preferences.app
4. Uncheck "Show date and time in menu bar"
5. Quit System Preferences.app

-----------------------------------------------------------
NEW IN THREE

- fixes dark mode and reduce transparency on macOS 10.15 Catalina
- wow, right?

-----------------------------------------------------------
KNOWN ISSUES

- using arrow keys to navigate menu after scrubbing menu with 
  mouse doesn't work (until you open the Preferences window?)
- clicking on calendar days is disabled (provided no utility, 
  produced poor rendering in dark mode)

-----------------------------------------------------------
THANKS FOR PLAYING

Day-O is offered as-is. I won't be offering support or taking
feature requests. That said, I hope Day-O treats you well!

http://shauninman.com/
